
Drop Database barbearia

create database barbearia;

use barbearia;

/*CLIENTES*/
create table clientes(
id int not null auto_increment ,
nome varchar(120) not null,
celular varchar(11) not null unique,
email varchar(120) not null unique,
cpf varchar(11) not null unique,
cidade varchar(120) not null,
estado varchar(2) not null,
pais varchar(80) not null,
rua varchar(120 ) not null,
numero varchar(10) not null,
bairro varchar(100) not null,
cep varchar(8) not null,
complemento varchar(150) not null,
dataNascimento datetime,
password varchar(150),
primary key(id)
);


/*PROFISSIONAIS*/
create table profissionais(
id int not null auto_increment ,
nome varchar(120) not null,
celular varchar(11) not null unique,
email varchar(120) not null unique,
cpf varchar(11) not null unique,
cidade varchar(120) not null,
estado varchar(2) not null,
pais varchar(80) not null,
rua varchar(120 ) not null,
numero varchar(10) not null,
bairro varchar(100) not null,
cep varchar(8) not null,
complemento varchar(150) not null,
dataNascimento datetime,
password varchar(150),
salario decimal (15,2),
primary key(id)
);

/*SERVIÇO*/
create table servico(
id int not null auto_increment,
nome varchar(80) not null unique,
descricao varchar(1000) not null,
duracao datetime not null,
preco decimal(15,2) not null,
profissionais_id int not null,
primary key(id),
constraint fk_servico_profissionais
foreign key (profissionais_id)
references profissionais(id)
);

/*TIPO DE PAGAMENTO*/
create table tipo_pagamento(
id int not null auto_increment,
nome varchar(150) not null unique,
taxa decimal(15,2) not null,
status varchar(120) not null,
primary key(id)
);

/*AGENDAS*/
create table agendas(
id int not null auto_increment,
tipo_pagamento  varchar(120) not null ,
valor decimal(15,2) not null,
datahora datetime not null,
profissionais_id int not null,
servico_id int not null,
clientes_id int not null,
tipo_pagamento_id int not null,
primary key(id),
constraint fk_agendas_profissionais
foreign key (profissionais_id)
references profissionais(id),
constraint fk_agendas_clientes
foreign key (clientes_id)
references clientes(id),
constraint fk_agendas_tipo_pagamento
foreign key (tipo_pagamento_id)
references tipo_pagamento(id),
constraint fk_agendas_servico
foreign key (servico_id)
references servico(id)
);


/*ADIMINISTRADOR*/
create table adm(
id int not null auto_increment ,
nome varchar(120) not null,
cpf varchar(11) not null unique,
email varchar(120) not null unique,
password varchar(150),
primary key(id)
);

